# Book Sorting Game ReadMe

## Introduction

The Book Sorting Game is a simple WPF (Windows Presentation Foundation) application that challenges users to sort a list of books based on their call numbers. This README file provides an overview of the application's functionality, how to run it, and important details for developers.

![Book Sorting Game]

## How to Play

1. **Launch the Game:**
   - When you run the application, you will be presented with the home screen.
   - Click on the "Start Game" button to begin.

2. **Select Difficulty:**
   - Choose the desired difficulty level: Easy, Medium, or Hard.
   - The task time will vary based on your selection.

3. **Game Screen:**
   - After selecting a difficulty level, you will be taken to the game screen.
   - The left side of the screen displays a list of randomly generated call numbers for books.
   - The right side of the screen is empty and is where you will sort the books.

4. **Sorting Books:**
   - To sort a book, click and drag it from the left list to the right list.
   - You can sort the books in any order you like.

5. **Check Order:**
   - Once you believe you have sorted the books correctly, click the "Check Order" button.
   - The game will compare your sorted list with the original list.

6. **Results:**
   - If your order is correct, you will see a message saying "Correct Order!"
   - If your order is incorrect, you will see a message saying "Wrong Order. Try again."

7. **Clear:**
   - You can clear the right list at any time by clicking the "Clear" button.

8. **Time Limit:**
   - Pay attention to the countdown timer at the bottom. If time runs out, the game will end automatically.

## Developer Information
-ST10117284
-cuanmoodley@gmail.com


### Technology Used

- **Programming Language:** C#
- **Framework:** .NET Framework (WPF)
- **IDE:** Visual Studio (or any other C# development environment)
- **Image Assets:** The application uses background images for the screens, which are placed in the "Images" folder.

### Code Overview

- The application has two screens: the home screen and the game screen.
- It uses WPF components such as buttons, text blocks, and list boxes for the user interface.
- Drag-and-drop functionality is implemented for sorting books.
- The game includes three difficulty levels, each with a different time limit.

### Customization

- Developers can customize the application by modifying the XAML (eXtensible Application Markup Language) for the user interface and the C# code for functionality.
- Additional difficulty levels, features, or improvements can be added based on requirements.

### Important Files

- **MainWindow.xaml:** Contains the XAML code for the application's user interface.
- **MainWindow.xaml.cs:** Contains the C# code for the application's logic.
- **Images:** The "Images" folder contains background images used in the application.

### Building and Running

To build and run the application:

1. Ensure you have a C# development environment, such as Visual Studio, installed.
2. Open the project folder in your development environment.
3. Build the project to ensure there are no errors.
4. Start the application by running it from your development environment.

### Contributions

Contributions to the codebase are welcome. If you want to contribute, please fork the repository, make your changes, and create a pull request.


### License

This project is open-source and available under the [MIT License](LICENSE).

## Acknowledgments

This application was created for educational purposes and is inspired by sorting games that challenge users' attention and organization skills.

Have fun playing the Book Sorting Game!
