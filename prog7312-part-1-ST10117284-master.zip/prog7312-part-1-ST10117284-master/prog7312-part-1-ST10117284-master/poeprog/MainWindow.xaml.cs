﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using System.Linq;
using System.Windows.Media;

namespace poeprog
{
    public partial class MainWindow : Window
    {
        private int score;
        private List<string> generatedCallNumbers;
        private int taskTimeInSeconds; // Added to store the task time in seconds
        private Timer timer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartTask_Click(object sender, RoutedEventArgs e)
        {

            if (homeScreenGrid.Visibility == Visibility.Visible)
            {
                // Hide the home screen
                homeScreenGrid.Visibility = Visibility.Collapsed;
                // Show the game screen
                gameScreenGrid.Visibility = Visibility.Visible;
            }

            // Show the game screen


            // Display the home screen
            ToggleHomeScreenVisibility(false);

            // Determine the task time based on the selected difficulty
            if (easyRadioButton.IsChecked == true)
            {
                taskTimeInSeconds = 280; // 3 minutes for easy
            }
            else if (mediumRadioButton.IsChecked == true)
            {
                taskTimeInSeconds = 120; // 2 minutes for medium
            }
            else if (hardRadioButton.IsChecked == true)
            {
                taskTimeInSeconds = 50; // 30 seconds for hard
            }

            generatedCallNumbers = GenerateRandomCallNumbers(10);
            callNumbersListBox.ItemsSource = generatedCallNumbers;
            targetListBox.ItemsSource = null; // Clear the target list

            // Start the task timer
            StartTaskTimer();

            // Display the countdown timer
            DisplayCountdownTimer();
        }

        private void DisplayCountdownTimer()
        {
            // Update the countdown timer display every second
            DispatcherTimer countdownTimer = new DispatcherTimer();
            countdownTimer.Interval = TimeSpan.FromSeconds(1);
            countdownTimer.Tick += (s, e) =>
            {
                if (taskTimeInSeconds > 0)
                {
                    taskTimeInSeconds--;
                    taskTimeTextBlock.Text = $"Time Left: {taskTimeInSeconds} seconds";
                }
                else
                {
                    countdownTimer.Stop();
                    EndTask();
                }
            };

            countdownTimer.Start();
        }

        private List<string> GenerateRandomCallNumbers(int count)
        {
            List<string> randomCallNumbers = new List<string>();
            Random random = new Random();

            for (int i = 0; i < count; i++)
            {
                string callNumber = $"{random.Next(1000):D3}.{(char)('A' + random.Next(26))}{(char)('A' + random.Next(26))}.{random.Next(100):D2}";
                randomCallNumbers.Add(callNumber);
            }

            return randomCallNumbers;
        }

        private void StartTaskTimer()
        {
            timer = new Timer(TimerCallback, null, 0, 1000); // Timer fires every 1 second
        }

        private void TimerCallback(object state)
        {
            if (taskTimeInSeconds > 0)
            {
                Dispatcher.Invoke(() =>
                {
                    taskTimeInSeconds--;
                    taskTimeTextBlock.Text = $"Time Left: {taskTimeInSeconds} seconds";
                });
            }
            else
            {
                Dispatcher.Invoke(() =>
                {
                    EndTask();
                });
            }
        }

        private void EndTask()
        {
            timer.Dispose(); // Stop the timer

            // Display the result or a message indicating that time is up
            resultText.Text = "Time is up. Check the order.";

            // Return to the home screen
            ToggleHomeScreenVisibility(true);
        }

        private void callNumbersListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (callNumbersListBox.SelectedItem != null)
            {
                DragDrop.DoDragDrop(callNumbersListBox, callNumbersListBox.SelectedItem, DragDropEffects.Move);
            }
        }

        private void targetListBox_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat))
            {
                string data = e.Data.GetData(DataFormats.StringFormat) as string;
                if (data != null)
                {
                    targetListBox.Items.Add(data);
                }
            }
        }

        private void CheckOrder_Click(object sender, RoutedEventArgs e)
        {
            List<string> originalCallNumbers = generatedCallNumbers; // Get the original call numbers
            List<string> sortedCallNumbers = targetListBox.Items.Cast<string>().ToList();

            bool isOrderCorrect = AreListsEqual(originalCallNumbers, sortedCallNumbers);

            if (isOrderCorrect)
            {
                // Calculate the score (for example, based on the remaining time)
                int timeBonus = taskTimeInSeconds * 10; // Adjust as needed
                score = timeBonus;

                resultText.Text = $"Correct Order! Score: {score}";
            }
            else
            {
                score = 0; // No score for an incorrect order
                resultText.Text = "Wrong Order. Try again.";
            }

            // Display the score
            DisplayScore();
        }

        private void DisplayScore()
        {
            scoreTextBlock.Text = $"Score: {score}";
            scoreTextBlock.Visibility = Visibility.Visible;
        }

        private bool AreListsEqual(List<string> list1, List<string> list2)
        {
            if (list1.Count != list2.Count)
            {
                return false; // If the counts are different, the lists can't be equal
            }

            for (int i = 0; i < list1.Count; i++)
            {
                if (list1[i] != list2[i])
                {
                    return false; // If any elements don't match, the lists are not equal
                }
            }

            return true; // If we reach this point, the lists are equal
        }

        private void targetListBox_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (targetListBox.SelectedItem != null)
            {
                DragDrop.DoDragDrop(targetListBox, targetListBox.SelectedItem, DragDropEffects.Move);
            }
        }


        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            targetListBox.Items.Clear();
        }

        private void ToggleHomeScreenVisibility(bool isVisible)
        {
            homeScreenGrid.Visibility = isVisible ? Visibility.Visible : Visibility.Collapsed;
            gameScreenGrid.Visibility = isVisible ? Visibility.Collapsed : Visibility.Visible;
        }

        private void TaskComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox comboBox = (ComboBox)sender;
            ComboBoxItem selectedItem = (ComboBoxItem)comboBox.SelectedItem;

            if (selectedItem != null && selectedItem.Content.ToString() == "Identifying areas")
            {
                // Open the new window when "Identifying areas" is selected
                NewWindow newWindow = new NewWindow();
                newWindow.Show();
            }
        }

        private void taskComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            
        }
    }
}
